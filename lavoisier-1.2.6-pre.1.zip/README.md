# Lavoisier
 Source code for the Vintage Story mod Lavoisier. Find the mod at https://mods.vintagestory.at/lavoisier.

Lavoisier (pronounced "lah-vwa-zee-ay") is a mod named after Antoine Lavoisier, the father of chemistry.
This mod adds early chemistry to the game.

Best used with ChemistryLib (coming soon).
